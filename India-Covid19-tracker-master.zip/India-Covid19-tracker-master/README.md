# India-Covid19-tracker'

![Site Screenshot](images/ss.png)